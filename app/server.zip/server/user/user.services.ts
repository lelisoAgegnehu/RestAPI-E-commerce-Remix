const getAll = async() => {}
const getById = async() => {}
const create = async() => {}
const update = async() => {}
const softDelete = async() => {}

export const userServices = {getAll, getById, create, update, softDelete }