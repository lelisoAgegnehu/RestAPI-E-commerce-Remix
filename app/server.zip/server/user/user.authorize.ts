const create = async() => {}
const update = async() => {}
const deleteUser = async() => {}

export const userAuthorization = {create, update, deleteUser}