const getAll = async() => {}
const getById = async() => {}
const create = async() => {}
const update = async() => {}
const deleteUser = async() => {}

export const userController = {getAll, getById, create, update, deleteUser }